int f(int a, int b) {
  int r;
  r = a + b;
  return r;
}

int main(void) {
  int x=5,y=3;
  return f(x,y);
}
